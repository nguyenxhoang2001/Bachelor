    #include<stdio.h>
    #include<iostream>
    int main(void)
    {
    // Ausgabe
    printf("Hello World\n");
    return 0;
    }
